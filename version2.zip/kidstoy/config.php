<?php 
$connect=mysqli_connect("localhost", "root","","barangmainan1") or die("failed...");
?>
